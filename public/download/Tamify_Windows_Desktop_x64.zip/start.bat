@echo off
title Tamify Desktop
cd /d "%~dp0"

start "" powershell.exe -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0launch.ps1"
exit
