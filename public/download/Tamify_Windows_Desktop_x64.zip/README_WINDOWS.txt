================================================================================
TAMIFY DESKTOP FOR WINDOWS (tamify.exe / Tamify-Desktop-x64.exe)
தமிழ் மற்றும் இந்திய மொழிகள் ஆவண அரங்கம் (TAMIL DOCUMENT STUDIO)
================================================================================

1. அறிமுகம் (INTRODUCTION):
   Tamify Desktop is a 100% offline standalone Windows application.
   No internet connection, no Node.js, and no installation wizard needed.

2. இயக்குவது எப்படி? (HOW TO RUN):
   • முறை 1 (Standard): Double-click 'tamify.exe' or 'Tamify-Desktop-x64.exe'.
   • முறை 2 (Fastest): In the ZIP folder, double-click 'start.bat'.
   • முறை 3 (Desktop Icon): Double-click 'Install-Desktop-Shortcut.bat' to put
     a 'Tamify தமிழ் ஆவண அரங்கம்' icon directly on your Windows Desktop!

3. உலாவி மூலம் நேரடியாக திறக்க (DIRECT BROWSER ACCESS):
   The app runs locally on: http://localhost:39080/
   You can also open this link in any browser (Edge, Chrome, Brave, Firefox).

4. கோப்பு பிழை சரிசெய்தல் (CORRUPTED / UNREADABLE / NOT LAUNCHING):
   If Windows displays "The file or directory is corrupted and unreadable" or blocks it:
   a) Method 1: Right-click 'tamify.exe' -> Select 'Properties'
      At the bottom under Security, check the box: [x] Unblock -> Click 'Apply' then 'OK'.
   b) Method 2: Extract the 'Tamify_Windows_Desktop_x64.zip' file (Right-click -> Extract All)
      and double-click 'start.bat'.
   c) Method 3: Run 'Install-Desktop-Shortcut.bat' to launch directly from your Desktop.

5. கணினி தேவைகள் (SYSTEM REQUIREMENTS):
   • Windows 10 (64-bit) or Windows 11 (64-bit)
   • 100% Offline (No Internet Required)
================================================================================
