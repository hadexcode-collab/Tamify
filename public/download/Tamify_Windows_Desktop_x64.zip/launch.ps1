# Tamify Desktop - Standalone Windows Launcher
# Zero-dependency local micro-server with Edge/Chrome App Mode
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue

$dir = $PSScriptRoot
if ([string]::IsNullOrEmpty($dir)) { $dir = (Get-Location).Path }

# Proactively cleanup stale caxa locks from previous runs
try {
    $tempCaxa = Join-Path $env:TEMP "caxa\applications"
    if (Test-Path $tempCaxa) {
        Get-ChildItem -Path $tempCaxa -Filter "tamify-*" -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    }
} catch { }

# Try HttpListener first, fallback to TcpListener if HttpListener permissions are restricted
$port = 39080
$maxAttempts = 30
$listener = $null
$isTcpFallback = $false

for ($i = 0; $i -lt $maxAttempts; $i++) {
    $testPort = $port + $i
    try {
        $temp = New-Object System.Net.HttpListener
        $temp.Prefixes.Add("http://127.0.0.1:$testPort/")
        $temp.Start()
        $listener = $temp
        $port = $testPort
        break
    } catch {
        if ($temp) { $temp.Close() }
    }
}

if ($null -eq $listener) {
    for ($i = 0; $i -lt $maxAttempts; $i++) {
        $testPort = $port + $i
        try {
            $tcp = New-Object System.Net.Sockets.TcpListener ([System.Net.IPAddress]::Loopback, $testPort)
            $tcp.Start()
            $listener = $tcp
            $port = $testPort
            $isTcpFallback = $true
            break
        } catch {
            if ($tcp) { $tcp.Stop() }
        }
    }
}

$url = "http://127.0.0.1:$port/"

# Search for Edge or Chrome executable for dedicated App Mode
$edgeCandidates = @(
    "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
    "$env:LOCALAPPDATA\Microsoft\Edge\Application\msedge.exe",
    "$env:ProgramW6432\Microsoft\Edge\Application\msedge.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
)

$browserExe = $null
foreach ($c in $edgeCandidates) {
    if (-not [string]::IsNullOrEmpty($c) -and (Test-Path $c)) {
        $browserExe = $c
        break
    }
}

if ($browserExe) {
    Start-Process $browserExe -ArgumentList "--app=$url", "--window-size=1440,920"
} else {
    Start-Process $url
}

$mimeTypes = @{
    ".html"  = "text/html; charset=utf-8"
    ".js"    = "application/javascript; charset=utf-8"
    ".mjs"   = "application/javascript; charset=utf-8"
    ".css"   = "text/css; charset=utf-8"
    ".json"  = "application/json; charset=utf-8"
    ".svg"   = "image/svg+xml"
    ".png"   = "image/png"
    ".jpg"   = "image/jpeg"
    ".jpeg"  = "image/jpeg"
    ".ico"   = "image/x-icon"
    ".woff2" = "font/woff2"
    ".woff"  = "font/woff"
    ".ttf"   = "font/ttf"
    ".pdf"   = "application/pdf"
    ".docx"  = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    ".xlsx"  = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
}

if ($isTcpFallback) {
    while ($listener.Server.IsBound) {
        try {
            $client = $listener.AcceptTcpClient()
            $stream = $client.GetStream()
            $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::ASCII)
            $reqLine = $reader.ReadLine()
            if ([string]::IsNullOrEmpty($reqLine)) { $client.Close(); continue }
            $parts = $reqLine.Split(' ')
            if ($parts.Length -lt 2) { $client.Close(); continue }
            $relPath = $parts[1].Split('?')[0].TrimStart('/')
            if ([string]::IsNullOrEmpty($relPath) -or $relPath -eq "index.html") { $relPath = "index.html" }
            $relPath = $relPath.Replace('/', [System.IO.Path]::DirectorySeparatorChar)
            $targetFile = [System.IO.Path]::Combine($dir, $relPath)
            if (-not [System.IO.File]::Exists($targetFile)) {
                $targetFile = [System.IO.Path]::Combine($dir, "index.html")
            }
            $ext = [System.IO.Path]::GetExtension($targetFile).ToLower()
            $ct = $mimeTypes[$ext]
            if ([string]::IsNullOrEmpty($ct)) { $ct = "application/octet-stream" }
            $content = [System.IO.File]::ReadAllBytes($targetFile)
            $crlf = "$([char]13)$([char]10)"
            $header = "HTTP/1.1 200 OK" + $crlf + "Content-Type: " + $ct + $crlf + "Content-Length: " + $content.Length + $crlf + "Connection: close" + $crlf + "Access-Control-Allow-Origin: *" + $crlf + $crlf
            $headerBytes = [System.Text.Encoding]::ASCII.GetBytes($header)
            $stream.Write($headerBytes, 0, $headerBytes.Length)
            $stream.Write($content, 0, $content.Length)
            $stream.Flush()
            $client.Close()
        } catch {
            try { if ($client) { $client.Close() } } catch { }
        }
    }
} else {
    while ($listener.IsListening) {
        try {
            $context = $listener.GetContext()
            $req = $context.Request
            $res = $context.Response

            $relPath = $req.Url.LocalPath.TrimStart('/')
            if ([string]::IsNullOrEmpty($relPath) -or $relPath -eq "index.html") {
                $relPath = "index.html"
            }

            $relPath = $relPath.Replace('/', [System.IO.Path]::DirectorySeparatorChar)
            $targetFile = [System.IO.Path]::Combine($dir, $relPath)

            if (-not [System.IO.File]::Exists($targetFile)) {
                $targetFile = [System.IO.Path]::Combine($dir, "index.html")
            }

            $ext = [System.IO.Path]::GetExtension($targetFile).ToLower()
            $contentType = $mimeTypes[$ext]
            if ([string]::IsNullOrEmpty($contentType)) {
                $contentType = "application/octet-stream"
            }

            $bytes = [System.IO.File]::ReadAllBytes($targetFile)
            $res.ContentType = $contentType
            $res.ContentLength64 = $bytes.Length
            $res.AddHeader("Cache-Control", "no-cache")
            $res.AddHeader("Access-Control-Allow-Origin", "*")
            $res.OutputStream.Write($bytes, 0, $bytes.Length)
            $res.OutputStream.Close()
        } catch {
            try {
                if ($res -and $res.OutputStream) { $res.OutputStream.Close() }
            } catch { }
        }
    }
}
