@echo off
title Tamify - Install Desktop Shortcut
cd /d "%~dp0"

powershell.exe -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $desktop = [Environment]::GetFolderPath('Desktop'); $s = $ws.CreateShortcut([System.IO.Path]::Combine($desktop, 'Tamify Desktop.lnk')); $s.TargetPath = [System.IO.Path]::Combine('%~dp0', 'start.bat'); $s.WorkingDirectory = '%~dp0'; $s.Description = 'Tamify - Tamil Document Studio (Offline)'; $s.Save()"

echo Desktop shortcut created on your Desktop!
timeout /t 2 >nul
exit
